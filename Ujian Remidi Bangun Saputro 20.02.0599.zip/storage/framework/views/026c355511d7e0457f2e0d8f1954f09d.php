<section class="container-fluid bg-warning">
    <div class="container text-center">
        <div class="">
            Bangun Saputra
        </div>
    </div>
</section><?php /**PATH C:\Users\NURA\Desktop\hot-project\2024\joki\bangun\web-crud\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>