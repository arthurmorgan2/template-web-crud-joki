<footer>
    <div class="container-fluid bg-warning">
        <div class="text-center fs-2 fw-bold py-3">
            Created by Mahasiswa Pengen Lulus
        </div>
    </div>
</footer>

</body>

</html><?php /**PATH C:\Users\NURA\Desktop\hot-project\2024\joki\bangun\template-web-crud-joki\resources\views/layouts/footer.blade.php ENDPATH**/ ?>