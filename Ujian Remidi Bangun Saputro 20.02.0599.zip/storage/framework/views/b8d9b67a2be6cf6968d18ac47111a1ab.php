<?php $__env->startSection('content'); ?>
<div class="container min-vh-100 my-5 bg-danger">
    <div class="row">
        <div class="col">
            tes
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NURA\Desktop\hot-project\2024\joki\bangun\web-crud\resources\views/create.blade.php ENDPATH**/ ?>