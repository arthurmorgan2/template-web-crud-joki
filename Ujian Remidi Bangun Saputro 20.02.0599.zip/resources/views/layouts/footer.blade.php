<footer>
    <div class="container-fluid bg-warning">
        <div class="text-center fs-2 fw-bold py-3">
            Created by Mahasiswa Pengen Lulus
        </div>
    </div>
</footer>

</body>

</html>